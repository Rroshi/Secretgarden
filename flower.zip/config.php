<?php
$conn = new mysqli("localhost", "id14056575_shoppingcart", "Asdfghjkl123.", "id14056575_shopping_cart");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>